import React, { useContext } from "react";
import { Link } from "react-router-dom";
import Home from "../pages/Home";
import Addproduct from "../pages/AddProduct";
import "../appcss/navbar.css";
import { AppContext } from "../contextAPI/AppContext";

const Navbar = () => {
  const { isLogged, handleLogout } = useContext(AppContext);

  const onLogoutClick = () => {
    handleLogout();
    navigate("/login");
  };

  return (
    <>
      <div className="navbar">
        <div className="navbar-left">
          <img
            src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAzwMBEQACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABAUBAgMGB//EAD0QAAEDAgQCBwQIBAcAAAAAAAEAAgMEEQUSITEGQRMUIlFhcaEyQoGRIyQzUnKSscEVFqLRJTQ1Q1Nigv/EABoBAQADAQEBAAAAAAAAAAAAAAABAgMEBQb/xAAsEQEAAgIBAwMEAQQDAQAAAAAAAQIDESEEEjETIkEFMlFhgRQjcaFCUpEk/9oADAMBAAIRAxEAPwD7igICAgICAgICAg0c8NSKocXSu77K8RCNtTfmbq8IlhAQZUSMh5GgPwUaiUujJRs4WKrNU7dQQRoVVLKAgICAgICAgICAgICAgIMONgg4PkJOUK8VjyrMoD8ToY5jC+rhbINC0vC19O8xuIZ+pWJ1KU1zXi7HBwPMG6pqflbcT4llEiIFMJFA51MzaeCSUgnKLkDmjPLfspMo2E4gMQp3yhhZldYgqWfT5/WrKe12U3CiY26du7H5gs5jSzdQCAgICAgICAgIBQakiyI3EMhEhIA1QR5H5j4LSsaVmVbjtQ+mwyZ0JtK4BkZ/7E2C2xVi142yyTqu3ajwahho2U7qWN9h2i9oJceZJWNs15tuJXjHXXLjJw3R3zUj56R426GQgD4bLSOqv/yjf+VZw1+OHM0eN032NXBVt+7UMyu/MFPfit5jX+FezJHztg4nVU/+ewqoYBu+D6QemvopjFWfttB6sx5h1pcZw6qfkhrIuk/439hw+BUWw5K+YWjLWU9ZbWhg2IsQCCLW3UpmNxqWI42RDJGxrG79kboitYr4bKUtmuylRMbIlIY7MAVlPC7ZAQEBAQEBAQEGDsg8/wAWiqNNF0GYxZvpA0E+V7K9XmfUYyTSOx14WbUCjf1jOGZ/o8+9kvpf6fGSMfvWkj82g2SId0y562NhrZShV4kOsYphlINukMz/ACaP7kLak6pazG/Noqvmrkh0shSBQak9xQRqvDqOtYW1dNFK3ue26tXJan2ypNKz8K7+XYYtcPqquiPIRyXb+V1wt/6q0x74if4Z+j/1lo6n4gpdY5KPEGDk8Ogf8xcH0UxbDb8x/tHbkr+2hxt0OmKYZW0lvfLOmZ8239Qrehv7LxP+pPV190JtHiVFWj6pVQynuY8XHw3CzviyY/uhaL1nxKUq7XdIXWNuRVLQmEhUWEBAQEBAQEBAQakX3CImIlzkflboLHuVojconiHEK6DyQ/Stw0da4hrp/cpo2QM8z2nfstcntxVr+eWWP3XmfwvVyugOgQcXynlt3q/bCu+Xjce40bh2PxUQzdXjP1l4bc+AA/VdmLo5vi73Lfqe2+l3hPEeG4o/JQVrJJOcTtHD4HVYW6e9I3aOGtM1b+JXUbg7ZYTDaG5UJann3IeVXi+E0NZTySzQMbMxpcydrbPYQNwd1riy2raNSytSsxLngdW+swuCWY3ky9o9/itMtYredIxzOuVgD2gs14SRqFlK7ZAQEBAQEBAQEGCQBqgjPJc661hRqpGJHBjHOOgAJTzIh8KsP8M6y/26uR058nHT0srdTPv7fxwz6ePZv8rlc7dxndYWCtWESg19R1ame9tukynIDzdyWtazadM7zqHga/hdta8zPqn9ZdrK92oc7nbuXqY83ZHbrhw3x907U9Xw9W4XGa2GYOdB2gW6EeK29auT2zDKcdqcw+qYPUyVGGUlRIAHyRNc63eQvFy1iLTEPTxz7Y2nVFRHTwOmlcAxo1JWMRzpN8kY6zaXl6nG66vm6Gha5jTsGC7iP2WnbEPFydblzW7cSHWNxWGI9adM2NwsTe4IPIq0TG9sck9Vjjut4ScExZtNannAbEdA8ctO5Tbdp26Ok6+Y9mR6cai6o9iNa48JUfsBZS0hsgICAgICAgICDlM6wsdyrVRLgtFRBWcSTOiwaobGfpJssDLb3eQ39ytMFYtdlmtqnHyuaSFtPTxQMHZjYGj4aLntbumZbViIjTsVVZHm9tXqrZV4xAyWJkjrkxm4AXRhnUssldxtWbBdP6Y/CNXsE1K6F0ZeJOyWjmOaRPbyiY29PTNDKaNjW5QGABvd4Lhnm0y6axOlJxbUuLoaUE5Q3MQOZUVj5eT9TyW4xwgRyOp8DdLTnLJLNke/7rbaBWny56T2dNunmfMmDzSurm07nOfHLcSMdexHfqonUI6PJa15r5hXytDZJGDYEgeKs5LxrJOvh6vh2pM2H5HE3idl17uSrL3vp+Wb4ufhfM9gLGXotkBAQEBAQEBAQR5Td3ktKqy5qyA6DRBU4iOtY7hVJuxj3Vbx+EWb/U4fJa09uK9v4Y3jd4qv27lcbpbqRxnbcgq1ZRLzmL8T4PQ1IoKiZ8lQ8hpjijzFtzzOwXVjwZbR31jw575qRPbLm6OVtS6B0bxbUOt2bd5PJaxkjW5ZzWd8LTD6NsLule4PcRoRsB3rnyZJs3rSE5vadYa2WU+Gjy/FcZbiQednRi3wU08PC+p1n1d/pAoqx1KHxvjbNDJ7cbtirWjbkw9R2e20bhZsfB/B6ipw2Dq8rTlfrmOU9yr86d1Zx+jN8MalQjZaPK+dvS8Jg9FOSNC4W+SpZ7f0umqTL1A0CxesICAgICAgICDBNggiuN3FbQpLCAdkkVuE/WeIMSqt2wBlKw+QzO9T6LTNM1w1r+dyyx+7JMrrOwOsXAG211yxHDbuiONt7os1NibEIh4/ibgqLEattfQPENTnDpGn2ZLH0K7en6yaR2zHDmy9PFuYVOL0fE5o6ymjhmlFXN2gHhwZGBoB5rox26bui0/DK0Zo3EL3gijxaiwt1LijA0McOgBdmLW22PxXN1V8dr91GuCLxX3PURsyjXdcky6YhVcRYf1yna9o+ljNxbu7lNZ05er6aM9J15h417XMfkkaWuHIrb42+avSacSm4XXMphPFO0uimjIIA58lWY5dXS564otW3iUNkbn5hG0nRWY4cU5LcQ9nw9E1lDG9oIzDW4tqsrS+k6akUxxELdUdAgICAgICAgINZDZhUwiUXmVqqINZZBFE+RxsGNLj8Amt8Qi06iZQ+FYizB4pZBaSpc6of5uN/wBLK3VW/uzEfHCuGPbv8s4ngsddP07Z5IpLAdk9yxidOfqOj9W3dFtIXUccovsKlszOQdv6q26y55xdVj+2dwyMdrqbStoHaaFzdEmsfCY63LT76L2iqW1dMydjXNDxcBwsVSXo4799e52sVXXLRkCyaBSMEXBBQeb4tpmRYa6WMDpXPbHFfcFxA/f0XR09e/JqXJ1WLHavMI1JgpfCHOZcnbtaKs254ZR0GLzMLelw2OGws2/3RsomzqpjrWPbGkkslhrYyxwFOWFrmk89wR81TZMWrbzwnDZVbMoCAgICAgICDnN7BU18olHWqomxWcRvIwuSFhs+oc2Fv/o2Ppda9Pr1Nz4hlln2rmBjYYWRgANY0NC5ZmZnbasarEGVjtWuU7SZZBsRZNwctS52z2AjyTSs8+Ybsc3RrdO4KJjS0eHS6hLKAgwUHm+JHmfFsOo26iPNUvHkMrfV3ouvBHbivf8AhzZZ3eKpcbZKqKSEExRMIaHNJBcQNVjJzkmYmOHZ1LUQ00fU5DnYfe1zeBuqTK3pTWvslvVllRFFGJmZumA0PvA3IUF/dWI3ztYBQ3ZQEBAQEBAQEHOb2Cpr5RKOtVQ+CgVdWOtY9h9N7sIdUOHiOyP1K0r7cU2/hlbm8QvXFrR2tiuZ0NMkZ1abK25VmDJINnAhNx8mmOkcPaYmoSyHx31FimpNslgcbh2qbmBi0jed04knZ0uUdoG/gE1+BuDf4qqXmKc9d4mr5r9mMsp2H8Iu7+o+i7bx24Kx+eXNT3XmVtTOlhmqDUM+hb2mOA27wuWVo7ome7w7fxCF9M6aNkj2g5bBtiT5FV0t6u67hEw6nY6ukmkDmy2EghJuI83Pz0UscdKzkm3yuBsqutlAQEBAQEBAQaSC7SpjyiUbnZaqiiSFbg46bG8TqT7hbA3yAuf1Wmbdcda/nllj1N5svCA7RwXM6GhiHkrdyGMjxsbpxPkM7x7TbpqPgYzxu3FinMDPRtOrXJtDdoI3N1CUVj5hXyRuBMRjBae431RSJt6n6dqmdtPTyzP9mNhefIBK17rREfK1p1EyouEaZ3UmVEw+llBmf+J5zH9l09Vb+52x8cM8Ee3b0LmhzSCNCuVswGtGlh4KUREIlG6OWoqpmA3DxGXHnl7viSjLH2za1oT1DYQEBAQEBAQEGDqEEZws4rSFJhqkiorKSso6uStwqRuaUDpYZGktd46bFb1tW8duT4ZTW1Z3RiPiKpg0rsMkA5vp3B4+W6j+npP2W/8AT1bR90J9LxDhdSQ1lWxjz7kvYd8is7dPkrzpeM1J+Vk17XC7XAjvBWMx+WsTsvqgyWg7gJEo006EHY2U7NMFj2nQ3CniRHrYZp4ssbix4Ic1w7wnCl6TaOOFXxPVtfhclCx31idzYCALe0dSPhdb9LWPU3Pwxy5I12/K3w9gjpmgABvLy2C55tNp3LoiNRpIzAXvoBzKhO9eUOoqJHmJtE0Pzu1k3a0DdSyveZ1FUqGJkTcrBYXJ+aTLSKxXw6qFhAQEBAQEBAQEHOVmbUK0SiYRwbGxCuqDRNIauijf7TGm++iJRJ8JpKgESRNIPJwuPVaRlvXxKJrWfMK48OmAl1DPPTHl0MpA/KbhXjqJni8RLKcURzWQTY/R/wC7T1bRynjyO/MNPROzDf40n+7Hzt3ZxMYW/wCIYZVwDnJEOlZ6a+irPSxP2W2etNfuhY0OO4XXnLS1sL3/AHM4DvynVZWwZKear1zY7fKwv4LJqxyUQQ89jVpseooGD7ON8z7eNmtv6rqxcYbT+XPesWyRC0paKSFrx1mQgts0F1w3xF1z7XjFrfLLKDNA6KonkmDzrmP9k2RijWpSoYWQxtZG0Na0WAChpFYrGodAESygICAgICAgICAgFBzfGHa81aJ0rMOLmOHLRW3s0qZ8cpYas05EhyuyueBoCrRDgv12Ot+1aA3AIOh1BUO2OeT1RLYMcdr6KJmDTBo43m72Nv3gWPoo7tJiESswCgq2ls0EcnhI2/rurVzZK+JVnHWfMIP8vS0v+nV1VTkbNbJnZ+Vy1/qe776xKno6+2WBUY/SfaNpKtu2ZwMRH6hR/wDPf9f7J9Wv7b4TR1MlbLV1pY+eUjPlBDWNGzRf9VXLkrNYpTxC1KTHNvL0IWDVlAQEBAQEBAQEBAQEBAQEGDsgoKnh2OesdM2Yhj3ZnNtzV4u8y/06tsnfteMja2wtsLKu5elEajTcNA5BRtOmUBAQYsgWQA0AWAsgyEBAQEBAQEBAQEBAQEBAQEBBiyDKAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICD//Z"
            alt="logo"
          />
        </div>

        {/* <div className="navbar-right">
          <Link to="/">Home</Link>
          <Link to="/add/products">Add Product</Link>
          <Link to={() => handleLogout}>Logout</Link>
        </div> */}
        <div className="navbar-right">
          <Link to="/">Home</Link>
          <Link to="/add/products">Add Product</Link>
          <button
            onClick={() => {
              if (isLogged) {
                onLogoutClick();
              } else {
                navigate("/login");
              }
            }}
            style={{
              marginLeft: "10px",
              padding: "5px 10px",
              cursor: "pointer",
            }}
          >
            {isLogged ? "Logout" : "Login"}
          </button>
        </div>
      </div>
    </>
  );
};

export default Navbar;
