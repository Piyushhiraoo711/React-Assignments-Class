import React, { useEffect, useState } from "react";
import CarouselSlider from "../slider/CarouselSlider";
import SwiperSlider from "../slider/SwiperSlider";
import { useSelector } from "react-redux";

const Home = () => {
  const [allMovies, setAllMovies] = useState([]);
  const currentuser = useSelector((state) => state.user.currentUser);
  const getMovies = async () => {
    fetch("/data.json")
      .then((res) => res.json())
      .then((data) => {
        setAllMovies(data.Search);
      
      })
      .catch((err) => console.error("Error fetching movies:", err));
  };

  useEffect(() => {
    getMovies();
  }, []);

  return (
    <>
   
      <div className="bg-black min-h-screen">
        <CarouselSlider movies={allMovies} />
      </div>
      <div className="bg-black min-h-screen text-white p-4">
        <SwiperSlider title="Trending Movies" movies={allMovies} />
        <SwiperSlider title="Top Rated" movies={allMovies} />
      </div>
    </>
  );
};

export default Home;
