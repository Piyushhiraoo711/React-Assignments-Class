import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useNavigate,
} from "react-router-dom";
import Navbar from "./components/Navbar";
import Login from "./pages/Login";
import Home from "./pages/Home";
import Edit from "./pages/EditProduct";
import ProductDetails from "./pages/ProductDetails";
import { AppContext } from "./contextAPI/AppContext";
import Addproduct from "./pages/AddProduct";
import { removeUser, saveUser } from "./utils/localStorage";
import ProtectedRoute from "./protectedRoutes/ProtectedRoutes";
import PublicRoute from "./protectedRoutes/PublicRoute";

function App() {
  const [user, setUser] = useState(null);
  const [isLogged, setIsLogged] = useState(false);
  const navigate = useNavigate();

  const handleLogin = (username, password) => {
    if (username === "admin" && password === "1234") {
      const userData = { username, password };
      setUser(userData);
      setIsLogged(true);
      saveUser(userData);
      navigate("/");
    } else {
      alert("Invalid credentials!");
    }
  };

  const handleLogout = () => {
    console.log("logout")
    setUser(null);
    setIsLogged(false);
    removeUser("user")
  };

  const value = {
    user,
    isLogged,
    handleLogin,
    handleLogout,
  };

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.stringify(storedUser));
      setIsLogged(true);
    }
  }, []);

  return (
    <AppContext.Provider value={value}>
      <Navbar />
      <Navbar />
        <Routes>
       
          <Route
            path="/login"
            element={
              <PublicRoute>
                <Login />
              </PublicRoute>
            }
          />

          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Home />
              </ProtectedRoute>
            }
          />
          <Route
            path="/edit/:id"
            element={
              <ProtectedRoute>
                <Edit />
              </ProtectedRoute>
            }
          />
          <Route
            path="/product/:id"
            element={
              <ProtectedRoute>
                <ProductDetails />
              </ProtectedRoute>
            }
          />
          <Route
            path="/add/products"
            element={
              <ProtectedRoute>
                <Addproduct />
              </ProtectedRoute>
            }
          />
        </Routes>
    </AppContext.Provider>
  );
}

export default App;
