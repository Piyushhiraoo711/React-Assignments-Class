import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

const API_URL = "/data.json";

export const fetchAllMovies = createAsyncThunk(
  "movies/fetchAllMovies",
  async (_, { rejectWithValue }) => {
    try {
      const res = await fetch(API_URL);
      const data = await res.json();
      return data.Search;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const fetchTrendingMovies = createAsyncThunk(
  "movies/fetchTrendingMovies",
  async (_, { getState, rejectWithValue }) => {
    try {
      const state = getState();
      const allMovies = state.movies.allMovies;

      const trending = allMovies.slice(0, 5);
      return trending;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const fetchPopularMovies = createAsyncThunk(
  "movies/fetchPopularMovies",
  async (_, { getState, rejectWithValue }) => {
    try {
      const state = getState();
      const allMovies = state.movies.allMovies;

      const popular = allMovies.slice(0, 10);
      return popular;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const fetchTopRatedMovies = createAsyncThunk(
  "movies/fetchTopRatedMovies",
  async (_, { getState, rejectWithValue }) => {
    try {
      const state = getState();
      const allMovies = state.movies.allMovies;

      const topRated = [...allMovies].sort(
        (a, b) => parseFloat(b.imdbRating || 0) - parseFloat(a.imdbRating || 0)
      );
      return topRated.slice(0, 10);
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

const initialState = {
  allMovies: [],
  trendingMovies: [],
  popularMovies: [],
  topRatedMovies: [],
  loading: false,
  error: null,
};

const movieSlice = createSlice({
  name: "movies",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder

      .addCase(fetchAllMovies.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllMovies.fulfilled, (state, action) => {
        state.loading = false;
        state.allMovies = action.payload;
      })
      .addCase(fetchAllMovies.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      .addCase(fetchTrendingMovies.fulfilled, (state, action) => {
        state.trendingMovies = action.payload;
      })

      .addCase(fetchPopularMovies.fulfilled, (state, action) => {
        state.popularMovies = action.payload;
      })

      .addCase(fetchTopRatedMovies.fulfilled, (state, action) => {
        state.topRatedMovies = action.payload;
      });
  },
});

export default movieSlice.reducer;
