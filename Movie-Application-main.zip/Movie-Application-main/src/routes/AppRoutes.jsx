import React from "react";
import { Route, Routes } from "react-router-dom";
import Home from "../features/Home.jsx";
import Login from "../authentication/Login.jsx";
import Signup from "../authentication/Signup.jsx";
import About from "../features/About.jsx";
import Contact from "../features/Contact.jsx";
import MovieDetails from "../features/MovieDetails.jsx";
import NotFound from "../features/NotFound.jsx";
import Profile from "../features/Profile.jsx";

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/profile" element={<Profile />} />
      <Route path="/movie/:id" element={<MovieDetails />} />
      <Route path="/404" element={<NotFound />} />
    </Routes>
  );
};

export default AppRoutes;

// <BrowserRouter>
//   <Routes>
//     <Route
//       path="/"
//       element={
//         <ProtectedRoute>
//           <Home />
//         </ProtectedRoute>
//       }
//     />

//     <Route
//       path="/login"
//       element={
//         <PublicRoute>
//           <Login />
//         </PublicRoute>
//       }
//     />

//     <Route
//       path="/signup"
//       element={
//         <PublicRoute>
//           <Signup />
//         </PublicRoute>
//       }
//     />

//     <Route
//       path="/about"
//       element={
//         <PublicRoute>
//           <About />
//         </PublicRoute>
//       }
//     />

//     <Route
//       path="/contact"
//       element={
//         <PublicRoute>
//           <Contact />{" "}
//         </PublicRoute>
//       }
//     />

//     <Route
//       path="/movie/:id"
//       element={
//         <PublicRoute>
//           <MovieDetails />
//         </PublicRoute>
//       }
//     />
//   </Routes>
// </BrowserRouter>
