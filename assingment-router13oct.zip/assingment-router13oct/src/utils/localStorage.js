export const saveUser = (userData) => {
  try {
    localStorage.setItem("user", JSON.stringify(userData));
  } catch (error) {
    console.error("Error", error);
  }
};

export const getUser = () => {
  try {
    const user = localStorage.getItem("user");
    return user ? JSON.parse(user) : null;
  } catch (error) {
    console.error("Error", error);
    return null;
  }
};

export const removeUser = () => {
  try {
    localStorage.removeItem("user");
  } catch (error) {
    console.error("Error", error);
  }
};
