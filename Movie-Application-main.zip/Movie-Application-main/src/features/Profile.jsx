import React from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";

const Profile = () => {
  const currentUser = useSelector((state) => state.user.currentUser);
  const favorites = currentUser?.favorites || [];

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center text-white">
        Please log in to see your profile.
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h1 className="text-3xl font-bold mb-6">
        {currentUser.username}'s Favorites
      </h1>
      {favorites.length === 0 ? (
        <p>No favorite movies yet.</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
          {favorites.map((movie) => (
            <Link to={`/movie/${movie.imdbID}`} key={movie.imdbID}>
              <div className="bg-gray-800 rounded-lg overflow-hidden hover:scale-105 transition-transform duration-300">
                <img
                  src={movie.Poster}
                  alt={movie.Title}
                  className="w-full h-64 object-cover"
                />
                <h3 className="text-white mt-2 text-center">{movie.Title}</h3>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};

export default Profile;
