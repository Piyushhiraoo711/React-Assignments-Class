// import React from "react";
// import { useSelector } from "react-redux";
// import { Navigate } from "react-router-dom";

// export const PublicRoute = ({ children }) => {
//   const currentUser = useSelector((state) => state.user.currentUser);

//   if (currentUser) {
//     return <Navigate to="/" replace />;
//   }

//   return children;
// };

// export const ProtectedRoute = ({ children }) => {
//   const currentUser = useSelector((state) => state.user.currentUser);


//   if (!currentUser) {
//     return <Navigate to="/login" replace />;
//   }

//   return children;
// };