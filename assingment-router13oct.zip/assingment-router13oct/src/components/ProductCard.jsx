import React from 'react'

const ProductCard = () => {
  return (
    <div>ProductCard</div>
  )
}

export default ProductCard