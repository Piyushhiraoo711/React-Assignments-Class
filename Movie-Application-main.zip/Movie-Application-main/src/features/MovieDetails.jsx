import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { addFavorite, removeFavorite } from "../slice/userSlice";

const MovieDetails = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const [movie, setMovie] = useState(null);
  const currentUser = useSelector((state) => state.user.currentUser);
  console.log("id", id);

  const fetchMovie = async () => {
    try {
      const res = await fetch(`https://www.omdbapi.com/?i=${id}&apikey=2fd9a034
          `);
      const data = await res.json();
      setMovie(data);
    } catch (err) {
      console.error("Error fetching movie:", err);
    }
  };
  const isFavorite =
    currentUser?.favorites?.some((m) => m.imdbID === movie.imdbID) || false;

  const handleFavorite = () => {
    if (!currentUser) return alert("Please login to add favorites");

    if (isFavorite) {
      console.log("fav")
      dispatch(removeFavorite(movie.imdbID));
    } else {
      dispatch(addFavorite(movie));
    }
  };
  useEffect(() => {
    fetchMovie();
  }, [id]);

  // Convert IMDb rating (out of 10) to stars (out of 5)
  // const rating = movie.imdbRating ? parseFloat(movie.imdbRating) / 2 : 0;
  // const fullStars = Math.floor(rating);
  // const halfStar = rating % 1 >= 0.5;

  if (!movie) return <p className="text-white text-center mt-10">Loading...</p>;

  return (
    <div className="min-h-screen from-gray-900 to-black text-white flex items-center justify-center p-6">
      <div className="max-w-5xl bg-gray-800 rounded-2xl shadow-xl overflow-hidden flex flex-col md:flex-row">
        {/* Poster */}
        <img
          src={movie.Poster}
          alt={movie.Title}
          className="w-full md:w-1/3 object-cover brightness-90"
        />

        {/* Details */}
        <div className="p-8 flex-1">
          <h1 className="text-4xl font-bold mb-3 text-yellow-400">
            {movie.Title}
          </h1>

          <div className="text-gray-300 space-y-2">
            <p>
              <span className="font-semibold text-white">Year:</span> {movie.Year}
            </p>
            <p>
              <span className="font-semibold text-white">Released:</span>{" "}
              {movie.Released || "N/A"}
            </p>
            <p>
              <span className="font-semibold text-white">Genre:</span> {movie.Genre || "N/A"}
            </p>
            <p>
              <span className="font-semibold text-white">Writer:</span> {movie.Writer || "N/A"}
            </p>
            <p>
              <span className="font-semibold text-white">Actors:</span> {movie.Actors || "N/A"}
            </p>
          </div>

          {/* Plot */}
          <p className="text-gray-400 mt-4 leading-relaxed">{movie.Plot}</p>

          {/* IMDb Rating */}
          <p className="text-gray-400 mt-4 leading-relaxed">
            <span>Rating: {movie.imdbRating || "N/A"}</span>
          </p>

          {/* Favorites Button */}
          <button
            onClick={() => handleFavorite()}
            className={`mt-4 px-5 py-2 rounded-lg font-semibold transition ${
              isFavorite
                ? "bg-red-500 hover:bg-red-400 text-white"
                : "bg-yellow-400 hover:bg-yellow-300 text-black"
            }`}
          >
            {isFavorite ? "Remove from Favorites" : "Add to Favorites"}
          </button>

          {/* Back Button */}
          <Link
            to="/"
            className="inline-block mt-6 px-5 py-2 bg-yellow-400 text-black rounded-lg hover:bg-yellow-500 transition"
          >
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default MovieDetails;
