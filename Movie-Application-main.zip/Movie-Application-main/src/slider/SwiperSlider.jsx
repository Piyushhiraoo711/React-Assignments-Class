import React, { useRef, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/autoplay";
import { Autoplay } from "swiper/modules";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";

const SwiperSlider = ({ title, movies = [] }) => {
  const swiperRef = useRef(null);
  const [isBeginning, setIsBeginning] = useState(true);
  const [isEnd, setIsEnd] = useState(false);
  const navigate = useNavigate();

  const handleSlideChange = (swiper) => {
    setIsBeginning(swiper.isBeginning);
    setIsEnd(swiper.isEnd);
  };
  return (
    <div className="relative bg-black text-white mb-10 w-full">
      <h2 className="text-lg sm:text-xl md:text-2xl font-semibold mb-4 px-4 sm:px-6">
        {title}
      </h2>

      <div className="relative group">
        {!isBeginning && (
          <button
            onClick={() => swiperRef.current.slidePrev()}
            className="absolute left-1 top-1/2 -translate-y-1/2 z-10 hidden md:flex items-center justify-center w-9 h-9 sm:w-10 sm:h-10 bg-black/60 hover:bg-black/80 rounded-full transition-all duration-300"
          >
            <ChevronLeft size={20} />
          </button>
        )}

        {!isEnd && (
          <button
            onClick={() => swiperRef.current.slideNext()}
            className="absolute right-1 top-1/2 -translate-y-1/2 z-10 hidden md:flex items-center justify-center w-9 h-9 sm:w-10 sm:h-10 bg-black/60 hover:bg-black/80 rounded-full transition-all duration-300"
          >
            <ChevronRight size={20} />
          </button>
        )}

        <Swiper
          modules={[Autoplay]}
          spaceBetween={10}
          slidesPerView={6}
          loop={false}
          onSwiper={(swiper) => (swiperRef.current = swiper)}
          onSlideChange={handleSlideChange}
          autoplay={{
            delay: 2500,
            disableOnInteraction: false,
          }}
          speed={800}
          breakpoints={{
            320: { slidesPerView: 2, spaceBetween: 8 },
            480: { slidesPerView: 2.5, spaceBetween: 8 },
            640: { slidesPerView: 3, spaceBetween: 10 },
            768: { slidesPerView: 4, spaceBetween: 12 },
            1024: { slidesPerView: 5, spaceBetween: 14 },
            1280: { slidesPerView: 6, spaceBetween: 16 },
          }}
          className="px-3 sm:px-5"
        >
          {movies.map((movie) => (
            <SwiperSlide key={movie.imdbID}>
              <div
                className="px-1 sm:px-2"
                onClick={() => navigate(`/movie/${movie.imdbID}`)}
              >
                <div className="relative">
                  <img
                    src={`${movie.Poster}`}
                    alt={movie.title}
                    className="w-full object-cover rounded-xl hover:scale-105 transition-transform duration-300"
                  />

                  <div className="absolute inset-0  from-black/60 via-transparent to-transparent opacity-0 hover:opacity-100 transition duration-300 rounded-xl" />
                </div>
                <p className="mt-2 text-center text-xs sm:text-sm truncate px-1">
                  {movie.Title}
                </p>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
};

export default SwiperSlider;
